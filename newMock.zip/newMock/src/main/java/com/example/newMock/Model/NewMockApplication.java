package com.example.newMock.Model;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
    @SpringBootApplication
    public class NewMockApplication {

        public static void main(String[] args) {
            SpringApplication.run(NewMockApplication.class, args);
        }
    }
